package principal;

import colaborador.Colaborador;

public class Principal {

	public static void main(String[] args) {
		
		//Instancia objeto da classe Colaborador
		Colaborador c = new Colaborador("Brenda", "brenda.bittencourt@gmail.com", "Centro - 1122", 27, "Gerente de Marketing", 8000);

	}

}
