package padr�o;

public abstract class Padrao {
	
	//M�todos padr�es
	public abstract void cadastrar();
	public abstract void alterar();
	public abstract void selecionar();
	public abstract void excluir();
	
	//M�todo para reutliza��o
	public void metodoDeReutilizacao() {
		
	}
	

}
