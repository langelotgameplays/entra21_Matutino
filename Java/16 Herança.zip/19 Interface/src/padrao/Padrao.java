package padrao;

public interface Padrao {
	
	//M�todos obrigat�rios
	public void cadastrar();
	public void alterar();
	public void selecionar();
	public void excluir();
	

}
