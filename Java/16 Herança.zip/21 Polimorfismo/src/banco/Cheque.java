package banco;

public class Cheque {

	// M�todo de Juros
	public void juros(double valor) {
		System.out.println("Taxa do cheque: " + valor * 0.05);
	}
	public void mensagem() {
		System.out.println("Voc� executou a classe cheque");
	}

}
