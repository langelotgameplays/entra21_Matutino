package beans;

public class Jogo {
	
	//Atributos
	private String nomeJogo, genero, plataforma, cIndicativa, valor;

	//Set & Get
	public String getNomeJogo() {
		return nomeJogo;
	}

	public void setNomeJogo(String nomeJogo) {
		this.nomeJogo = nomeJogo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

	public String getcIndicativa() {
		return cIndicativa;
	}

	public void setcIndicativa(String cIndicativa) {
		this.cIndicativa = cIndicativa;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
	
	
	

}
