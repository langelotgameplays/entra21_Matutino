package principal;

import formulario.Formulario;

public class Principal {

	public static void main(String[] args) {
		
		//Inst�nciar um objeto da classe
		Formulario f = new Formulario();
		f.setVisible(true);
	}

}
