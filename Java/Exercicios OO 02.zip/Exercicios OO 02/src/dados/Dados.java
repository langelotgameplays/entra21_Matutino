package dados;

import java.util.ArrayList;

import beans.Jogo;

public class Dados {
	
	//ArrayList
	public static ArrayList<Jogo> arrayJogos = new ArrayList<Jogo>();

}
