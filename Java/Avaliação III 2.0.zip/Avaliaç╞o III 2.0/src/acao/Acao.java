package acao;

public class Acao {
	
	//Estatisticas
	public void quantidade() {
		
	}
	
	//Atualizar quantidade

}
