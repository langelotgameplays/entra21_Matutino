package dados;

import java.util.ArrayList;

import beans.Beans;

public class Dados {

	ArrayList<Beans> arrayDados = new ArrayList<Beans>();
	
}
