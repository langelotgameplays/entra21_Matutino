package beans;

public class Beans {
	

}
