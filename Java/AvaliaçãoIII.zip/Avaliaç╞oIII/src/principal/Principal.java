package principal;

import formularios.Formulario;

public class Principal {

	public static void main(String[] args) {
		
		Formulario f = new Formulario();
		f.setVisible(true);
		

	}

}
