package beans;

public class Beans {
	
	//Atributos
	private String colaborador, cargo, cFidelidade, pSaude;
	private int sBruto, vTransporte, iRenda, sLiquido, faltas;
	
	//Get & Set
	public String getColaborador() {
		return colaborador;
	}
	public void setColaborador(String colaborador) {
		this.colaborador = colaborador;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public String getcFidelidade() {
		return cFidelidade;
	}
	public void setcFidelidade(String cFidelidade) {
		this.cFidelidade = cFidelidade;
	}
	public String getpSaude() {
		return pSaude;
	}
	public void setpSaude(String pSaude) {
		this.pSaude = pSaude;
	}
	public int getsBruto() {
		return sBruto;
	}
	public void setsBruto(int sBruto) {
		this.sBruto = sBruto;
	}
	public int getvTransporte() {
		return vTransporte;
	}
	public void setvTransporte(int vTransporte) {
		this.vTransporte = vTransporte;
	}
	public int getiRenda() {
		return iRenda;
	}
	public void setiRenda(int iRenda) {
		this.iRenda = iRenda;
	}
	public int getsLiquido() {
		return sLiquido;
	}
	public void setsLiquido(int sLiquido) {
		this.sLiquido = sLiquido;
	}
	public int getFaltas() {
		return faltas;
	}
	public void setFaltas(int faltas) {
		this.faltas = faltas;
	}
	
	
}
	