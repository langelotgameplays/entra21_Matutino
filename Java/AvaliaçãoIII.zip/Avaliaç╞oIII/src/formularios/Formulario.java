package formularios;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import acao.Acao;
import beans.Beans;
import dados.Dados;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;

@SuppressWarnings("serial")
public class Formulario extends JFrame {

	private JPanel contentPane;
	private JTextField txtColaborador;
	private JTextField txtSalarioBruto;
	private JTextField textField;
	private JTextField txtImpostoRenda;
	private JTextField txtSalarioLiquido;
	private JTable table;
	private static int codigoDados;

	private void limparCampos() {

		// Limpar os campos
		// .setText("");

		// Focus
		// .requestFocus();

	}

	public Formulario() {

		Acao a = new Acao();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 620, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		// JLabel
		JLabel lblColaborador = new JLabel("Colaborador");
		lblColaborador.setBounds(10, 11, 90, 30);
		contentPane.add(lblColaborador);

		JLabel lblSalarioBruto = new JLabel("Salario Bruto");
		lblSalarioBruto.setBounds(10, 52, 90, 30);
		contentPane.add(lblSalarioBruto);

		JLabel lblValeTransporte = new JLabel("Vale Transporte");
		lblValeTransporte.setBounds(10, 93, 90, 30);
		contentPane.add(lblValeTransporte);

		JLabel lblFaltasNoMes = new JLabel("Faltas no m�s");
		lblFaltasNoMes.setBounds(10, 134, 90, 30);
		contentPane.add(lblFaltasNoMes);

		JLabel lblImpostoDeRenda = new JLabel("Imposto de Renda");
		lblImpostoDeRenda.setBounds(300, 93, 90, 30);
		contentPane.add(lblImpostoDeRenda);

		JLabel lblSalarioLiquido = new JLabel("Salario Liquido");
		lblSalarioLiquido.setBounds(300, 134, 90, 30);
		contentPane.add(lblSalarioLiquido);

		JLabel lblCargo = new JLabel("Cargo");
		lblCargo.setBounds(300, 11, 90, 30);
		contentPane.add(lblCargo);

		// JTextField
		txtColaborador = new JTextField();
		txtColaborador.setBounds(110, 11, 180, 30);
		contentPane.add(txtColaborador);
		txtColaborador.setColumns(10);

		txtSalarioBruto = new JTextField();
		txtSalarioBruto.setEnabled(false);
		txtSalarioBruto.setBounds(110, 52, 180, 30);
		contentPane.add(txtSalarioBruto);
		txtSalarioBruto.setColumns(10);

		textField = new JTextField();
		textField.setEnabled(false);
		textField.setBounds(132, 93, 158, 30);
		contentPane.add(textField);
		textField.setColumns(10);

		txtImpostoRenda = new JTextField();
		txtImpostoRenda.setEnabled(false);
		txtImpostoRenda.setBounds(400, 93, 180, 30);
		contentPane.add(txtImpostoRenda);
		txtImpostoRenda.setColumns(10);

		txtSalarioLiquido = new JTextField();
		txtSalarioLiquido.setEnabled(false);
		txtSalarioLiquido.setBounds(400, 134, 180, 30);
		contentPane.add(txtSalarioLiquido);
		txtSalarioLiquido.setColumns(10);

		// JButton
		JButton btnCadastrarColaborador = new JButton("Cadastrar Colaborador");
		btnCadastrarColaborador.setBounds(10, 175, 180, 30);
		contentPane.add(btnCadastrarColaborador);

		JButton btnEstatisticas = new JButton("Estat�sticas");
		btnEstatisticas.setBounds(200, 175, 180, 30);
		contentPane.add(btnEstatisticas);

		JCheckBox chbValeTransporte = new JCheckBox("");
		chbValeTransporte.setBounds(106, 97, 20, 30);
		contentPane.add(chbValeTransporte);

		JCheckBox chbClubeFidelidade = new JCheckBox("Clube Fidelidade");
		chbClubeFidelidade.setBounds(296, 52, 180, 30);
		contentPane.add(chbClubeFidelidade);

		JCheckBox chbPlanoDeSade = new JCheckBox("Plano de Sa�de");
		chbPlanoDeSade.setBounds(478, 52, 180, 30);
		contentPane.add(chbPlanoDeSade);

		// JComboBox
		JComboBox cbCargo = new JComboBox();
		cbCargo.setBounds(400, 11, 180, 30);
		contentPane.add(cbCargo);
		cbCargo.addItem("...");
		cbCargo.addItem("Estagi�rio");
		cbCargo.addItem("Desenvolvedor Jr");
		cbCargo.addItem("Desenvolvedor Pleno");
		cbCargo.addItem("Desenvolvedor S�nior");
		cbCargo.addItem("Analista de Sistemas Jr");
		cbCargo.addItem("Analista de Sistemas Pleno");
		cbCargo.addItem("Analista de Sistemas S�nior");
		cbCargo.addItem("Arquiteto de Software");

		// JSpinner
		JSpinner spnFaltas = new JSpinner();
		spnFaltas.setBounds(110, 134, 60, 30);
		contentPane.add(spnFaltas);

		// JScrollPane
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setBounds(10, 216, 584, 234);
		contentPane.add(scrollPane);

		// JTable
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {

				// Obter o indice da tabela
				int indice = table.getSelectedRow();

				// Obter o valor do indice no atributo
				codigoDados = indice;

				// Selecionando dados do Curso
				txtColaborador.setText(table.getValueAt(indice, 0).toString());

			}
		});

		table.setModel(a.selecionar());
		scrollPane.setViewportView(table);

		btnCadastrarColaborador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Criar um objeto
				Beans b = new Beans();
				b.setColaborador(txtColaborador.getText());

				// Efetuar cadastro
				a.cadastrar(b);

				// Sele��o do ComboBox
				cbCargo.getSelectedItem();

				// Atualizar tabela
				table.setModel(a.selecionar());

			}
		});

	}
}
