package acao;

import javax.swing.table.DefaultTableModel;

import beans.Beans;
import dados.Dados;

public class Acao {

	// Cadastrar
	public void cadastrar(Beans b) {
		Dados.arrayDados.add(b);

	}

	// Selecionar
	public DefaultTableModel selecionar() {

		DefaultTableModel modelo = new DefaultTableModel();
		modelo.addColumn("Colaborador");
		modelo.addColumn("Sal�rio Liquido");

		for (int indice = 0; indice < Dados.arrayDados.size(); indice++) {
			modelo.addRow(new Object[] {

			});
		}
		return modelo;
	}

}
